The artist of my Project is Drake

I chose Drake because I have always loved his music, I have always been a fan and he has inspired me into loving music the way I do today.
Some Problems I have had during this project
1. For one, this project has been especially difficult for me, I am unsure of why I have had so mny problems but I have had problems trying to even get simple problems to work
2. Another problem I've had was trying to push the app to Heroku
3. It took me hours to get the app to finally work
